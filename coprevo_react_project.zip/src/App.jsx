import React from "react";

export default function App() {
  return (
    <div className="bg-gray-900 text-gray-200 min-h-screen font-sans">
      <header className="flex justify-between items-center p-6 border-b border-gray-800">
        <div className="text-3xl font-bold">
          <span className="text-blue-400">C</span>
          <span className="text-green-400">o</span>
          <span className="text-blue-400">p</span>
          <span className="text-green-400">r</span>
          <span className="text-blue-400">e</span>
          <span className="text-green-400">v</span>
          <span className="text-green-400">o</span>
        </div>
        <nav className="space-x-6 text-gray-300">
          <a href="#home" className="hover:text-blue-400">Home</a>
          <a href="#about" className="hover:text-blue-400">About</a>
          <a href="#services" className="hover:text-blue-400">Services</a>
          <a href="#contact" className="hover:text-blue-400">Contact</a>
        </nav>
      </header>

      <section id="home" className="relative flex flex-col items-center justify-center text-center py-32 px-6 bg-cover bg-center" style={{backgroundImage: "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1600&q=80')"}}>
        <h1 className="text-5xl font-extrabold mb-4 text-blue-400">Digital Transformation Starts Here</h1>
        <p className="text-gray-300 max-w-xl mb-6">Helping executives evolve IT leadership and modernize businesses for the future.</p>
        <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-full">Get Started</button>
      </section>

      <section id="about" className="max-w-5xl mx-auto py-20 px-6">
        <h2 className="text-3xl font-bold text-blue-400 mb-6">About Coprevo</h2>
        <p className="text-gray-400 leading-relaxed">Coprevo is an IT consulting firm specializing in digital transformation and executive IT leadership coaching. We empower organizations to cooperate effectively, manage projects strategically, and evolve their business models for the digital age.</p>
      </section>

      <section id="services" className="bg-gray-800 py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-blue-400 mb-10 text-center">Our Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {title: "Digital Transformation Strategy", desc: "Tailored strategies to evolve your business into a digital-first organization."},
              {title: "Executive IT Leadership Coaching", desc: "Coaching for IT leaders to drive innovation and lead change."},
              {title: "Project Management Excellence", desc: "Guidance to manage critical IT projects efficiently and effectively."}
            ].map((service, i) => (
              <div key={i} className="bg-gray-900 rounded-lg p-6 shadow-md hover:shadow-lg transition">
                <h3 className="text-xl font-semibold text-green-400 mb-3">{service.title}</h3>
                <p className="text-gray-400">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="max-w-3xl mx-auto py-20 px-6 text-center">
        <h2 className="text-3xl font-bold text-blue-400 mb-6">Contact Us</h2>
        <p className="text-gray-400 mb-4">Let’s discuss how we can help transform your business.</p>
        <button className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-full">Contact Coprevo</button>
      </section>

      <footer className="text-center py-6 text-gray-500 border-t border-gray-800 text-sm">
        © {new Date().getFullYear()} Coprevo. All rights reserved.
      </footer>
    </div>
  );
}
